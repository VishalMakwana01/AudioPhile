#!/bin/bash

docker build --rm -t nvidia_joc_maskrcnn_pt . -f Dockerfile