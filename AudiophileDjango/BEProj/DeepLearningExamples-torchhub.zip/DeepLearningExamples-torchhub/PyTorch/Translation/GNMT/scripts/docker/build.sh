#!/bin/bash

docker build . --rm -t gnmt
