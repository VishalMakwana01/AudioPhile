#!/bin/bash

set -e

python3 -m launch train.py
