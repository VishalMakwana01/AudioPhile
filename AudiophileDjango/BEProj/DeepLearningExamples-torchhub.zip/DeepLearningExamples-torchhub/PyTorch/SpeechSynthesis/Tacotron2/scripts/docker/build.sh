#!/bin/bash

docker build . --rm -t tacotron2
